// Flat-top hex grid, 9 straight vertical columns x 9 rows, "odd-q" offset layout.
export interface OffsetHex { row: number; col: number }
export interface Cube { x: number; y: number; z: number }

export const ROWS = 9;
export const COLS = 9;
export const rowLen = (_row: number) => COLS;

/** odd-q vertical layout (odd columns pushed down by half a hex) */
export function evenrToCube({ row, col }: OffsetHex): Cube {
  const x = col;
  const z = row - (col - (col & 1)) / 2;
  return { x, y: -x - z, z };
}

export function cubeToEvenr(c: Cube): OffsetHex {
  const col = c.x;
  const row = c.z + (c.x - (c.x & 1)) / 2;
  return { row, col };
}

export function cubeRound(x: number, y: number, z: number): Cube {
  let rx = Math.round(x), ry = Math.round(y), rz = Math.round(z);
  const dx = Math.abs(rx - x), dy = Math.abs(ry - y), dz = Math.abs(rz - z);
  if (dx > dy && dx > dz) rx = -ry - rz;
  else if (dy > dz) ry = -rx - rz;
  else rz = -rx - ry;
  return { x: rx, y: ry, z: rz };
}

export function hexDistance(a: OffsetHex, b: OffsetHex): number {
  const ac = evenrToCube(a), bc = evenrToCube(b);
  return (Math.abs(ac.x - bc.x) + Math.abs(ac.y - bc.y) + Math.abs(ac.z - bc.z)) / 2;
}

export function inBounds(h: OffsetHex) {
  return h.row >= 0 && h.row < ROWS && h.col >= 0 && h.col < COLS;
}

const CUBE_DIRS: Cube[] = [
  { x: 1, y: -1, z: 0 }, { x: 1, y: 0, z: -1 }, { x: 0, y: 1, z: -1 },
  { x: -1, y: 1, z: 0 }, { x: -1, y: 0, z: 1 }, { x: 0, y: -1, z: 1 },
];

/** all 6 surrounding hexes (top-left, top, top-right, bottom-right, bottom, bottom-left) */
export function neighbors(h: OffsetHex): OffsetHex[] {
  const c = evenrToCube(h);
  return CUBE_DIRS.map((d) => cubeToEvenr({ x: c.x + d.x, y: c.y + d.y, z: c.z + d.z })).filter(inBounds);
}

// Straight line of hexes from a to b (inclusive of both endpoints).
export function hexLine(a: OffsetHex, b: OffsetHex): OffsetHex[] {
  const n = hexDistance(a, b);
  if (n === 0) return [a];
  const ac = evenrToCube(a), bc = evenrToCube(b);
  const out: OffsetHex[] = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const c = cubeRound(ac.x + (bc.x - ac.x) * t, ac.y + (bc.y - ac.y) * t, ac.z + (bc.z - ac.z) * t);
    out.push(cubeToEvenr(c));
  }
  return out;
}

// Is a and b on one of the 6 straight cube vectors?
export function isStraightLine(a: OffsetHex, b: OffsetHex): boolean {
  const ac = evenrToCube(a), bc = evenrToCube(b);
  const d = { x: bc.x - ac.x, y: bc.y - ac.y, z: bc.z - ac.z };
  return d.x === 0 || d.y === 0 || d.z === 0;
}

/* ── flat-top pixel geometry ── */
export function hexToPixel(row: number, col: number, size: number) {
  const width = 2 * size;                 // corner to corner (horizontal)
  const height = Math.sqrt(3) * size;     // flat to flat (vertical)
  const x = col * (width * 0.75) + width / 2;
  const y = row * height + (col & 1 ? height / 2 : 0) + height / 2;
  return { x, y };
}

export function boardDimensions(size: number) {
  const width = 2 * size;
  const height = Math.sqrt(3) * size;
  return {
    w: (COLS - 1) * width * 0.75 + width,
    h: ROWS * height + height / 2,
    hexW: width,
    hexH: height,
  };
}

/** flat-top hexagon corner path */
export function hexPoints(cx: number, cy: number, size: number): string {
  const pts: string[] = [];
  for (let i = 0; i < 6; i++) {
    const angle = (60 * i * Math.PI) / 180;
    pts.push(`${cx + size * Math.cos(angle)},${cy + size * Math.sin(angle)}`);
  }
  return pts.join(" ");
}

export function allHexes(): OffsetHex[] {
  const out: OffsetHex[] = [];
  for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) out.push({ row: r, col: c });
  return out;
}

export const eqHex = (a: OffsetHex | null | undefined, b: OffsetHex | null | undefined) =>
  !!a && !!b && a.row === b.row && a.col === b.col;

export const hexKey = (h: OffsetHex) => `${h.row},${h.col}`;
