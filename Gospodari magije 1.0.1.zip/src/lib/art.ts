import a_beli_zmaj from "@/assets/tiles/beli-zmaj.png.asset.json";
import a_card_back from "@/assets/tiles/card-back.png.asset.json";
import a_crni_zmaj from "@/assets/tiles/crni-zmaj.png.asset.json";
import a_demon from "@/assets/tiles/demon.png.asset.json";
import a_duh from "@/assets/tiles/duh.png.asset.json";
import a_dzin from "@/assets/tiles/dzin.png.asset.json";
import a_grifon from "@/assets/tiles/grifon.png.asset.json";
import a_grifon2 from "@/assets/tiles/grifon2.png.asset.json";
import a_haos from "@/assets/tiles/haos.png.asset.json";
import a_harpija from "@/assets/tiles/harpija.png.asset.json";
import a_hidra from "@/assets/tiles/hidra.png.asset.json";
import a_jednorog from "@/assets/tiles/jednorog.png.asset.json";
import a_kentaur from "@/assets/tiles/kentaur.png.asset.json";
import a_konj from "@/assets/tiles/konj.png.asset.json";
import a_kostur from "@/assets/tiles/kostur.png.asset.json";
import a_krila from "@/assets/tiles/krila.png.asset.json";
import a_kristal from "@/assets/tiles/kristal.png.asset.json";
import a_krokodil from "@/assets/tiles/krokodil.png.asset.json";
import a_kula from "@/assets/tiles/kula.png.asset.json";
import a_lav from "@/assets/tiles/lav.png.asset.json";
import a_letece_cizme from "@/assets/tiles/letece-cizme.png.asset.json";
import a_ljudozder from "@/assets/tiles/ljudozder.png.asset.json";
import a_mac from "@/assets/tiles/mac.png.asset.json";
import a_mag_beli from "@/assets/tiles/mag-beli.png.asset.json";
import a_mag_crni from "@/assets/tiles/mag-crni.png.asset.json";
import a_mag_crveni from "@/assets/tiles/mag-crveni.png.asset.json";
import a_mag_zeleni from "@/assets/tiles/mag-zeleni.png.asset.json";
import a_magicni_luk from "@/assets/tiles/magicni-luk.png.asset.json";
import a_medved from "@/assets/tiles/medved.png.asset.json";
import a_minotaur from "@/assets/tiles/minotaur.png.asset.json";
import a_moc from "@/assets/tiles/moc.png.asset.json";
import a_mumija from "@/assets/tiles/mumija.png.asset.json";
import a_munja from "@/assets/tiles/munja.png.asset.json";
import a_nebeski_zmaj from "@/assets/tiles/nebeski-zmaj.png.asset.json";
import a_oklop from "@/assets/tiles/oklop.png.asset.json";
import a_ork from "@/assets/tiles/ork.png.asset.json";
import a_pegaz from "@/assets/tiles/pegaz.png.asset.json";
import a_sablast from "@/assets/tiles/sablast.png.asset.json";
import a_sekira from "@/assets/tiles/sekira.png.asset.json";
import a_slepi_mis from "@/assets/tiles/slepi-mis.png.asset.json";
import a_stit from "@/assets/tiles/stit.png.asset.json";
import a_trol from "@/assets/tiles/trol.png.asset.json";
import a_utvara from "@/assets/tiles/utvara.png.asset.json";
import a_vampir from "@/assets/tiles/vampir.png.asset.json";
import a_vilenjak from "@/assets/tiles/vilenjak.png.asset.json";
import a_vlast from "@/assets/tiles/vlast.png.asset.json";
import a_vuk from "@/assets/tiles/vuk.png.asset.json";
import a_zid from "@/assets/tiles/zid.png.asset.json";
import a_zombi from "@/assets/tiles/zombi.png.asset.json";

export const ART: Record<string, string> = {
  "beli-zmaj": a_beli_zmaj.url,
  "card-back": a_card_back.url,
  "crni-zmaj": a_crni_zmaj.url,
  "demon": a_demon.url,
  "duh": a_duh.url,
  "dzin": a_dzin.url,
  "grifon": a_grifon.url,
  "grifon2": a_grifon2.url,
  "haos": a_haos.url,
  "harpija": a_harpija.url,
  "hidra": a_hidra.url,
  "jednorog": a_jednorog.url,
  "kentaur": a_kentaur.url,
  "konj": a_konj.url,
  "kostur": a_kostur.url,
  "krila": a_krila.url,
  "kristal": a_kristal.url,
  "krokodil": a_krokodil.url,
  "kula": a_kula.url,
  "lav": a_lav.url,
  "letece-cizme": a_letece_cizme.url,
  "ljudozder": a_ljudozder.url,
  "mac": a_mac.url,
  "mag-beli": a_mag_beli.url,
  "mag-crni": a_mag_crni.url,
  "mag-crveni": a_mag_crveni.url,
  "mag-zeleni": a_mag_zeleni.url,
  "magicni-luk": a_magicni_luk.url,
  "medved": a_medved.url,
  "minotaur": a_minotaur.url,
  "moc": a_moc.url,
  "mumija": a_mumija.url,
  "munja": a_munja.url,
  "nebeski-zmaj": a_nebeski_zmaj.url,
  "oklop": a_oklop.url,
  "ork": a_ork.url,
  "pegaz": a_pegaz.url,
  "sablast": a_sablast.url,
  "sekira": a_sekira.url,
  "slepi-mis": a_slepi_mis.url,
  "stit": a_stit.url,
  "trol": a_trol.url,
  "utvara": a_utvara.url,
  "vampir": a_vampir.url,
  "vilenjak": a_vilenjak.url,
  "vlast": a_vlast.url,
  "vuk": a_vuk.url,
  "zid": a_zid.url,
  "zombi": a_zombi.url,
};

export const artOf = (id: string) => ART[id] ?? ART["moc"];
