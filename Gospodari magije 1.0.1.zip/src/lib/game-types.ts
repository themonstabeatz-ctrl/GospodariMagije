import { artOf } from "@/lib/art";
import type { DrawnCard } from "@/lib/cards";
import type { OffsetHex } from "@/lib/hex";

export type PlayerId = 1 | 2 | 3 | 4;
/** setup = manual crystal placement, play = main turn loop */
export type Stage = "setup" | "play" | "over";
export type GameMode = "solo" | "hotseat" | "online";

export interface Unit {
  uid: string;
  owner: PlayerId | 0; // 0 = neutral (crystal)
  card: DrawnCard;
  hex: OffsetHex;
  isWizard?: boolean;
  /** creature the wizard is currently riding */
  mount?: DrawnCard | null;
  /** wizard has Leteće Čizme (+2 movement) */
  boots?: boolean;
  summonedOn: number;
  moved: boolean;
  attacked: boolean;
}

export interface Player {
  id: PlayerId;
  name: string;
  color: string;
  portrait: string;
  art: string;
  isBot: boolean;
  powers: number;
  hand: DrawnCard[];
  alive: boolean;
}

export const PLAYER_META: Record<PlayerId, { name: string; color: string; art: string; log: string; panelBg: string; panelBorder: string }> = {
  1: { name: "Beli Mag", color: "oklch(0.92 0.02 90)", art: "mag-beli", log: "oklch(0.92 0.02 90)", panelBg: "oklch(0.18 0.01 80 / 0.6)", panelBorder: "oklch(0.92 0.02 90 / 0.5)" },
  2: { name: "Crni Mag", color: "#c8c8c8", art: "mag-crni", log: "#d6d6d6", panelBg: "#121212", panelBorder: "#2b2b2b" },
  3: { name: "Crveni Mag", color: "oklch(0.62 0.22 25)", art: "mag-crveni", log: "oklch(0.66 0.22 25)", panelBg: "oklch(0.18 0.04 25 / 0.6)", panelBorder: "oklch(0.62 0.22 25 / 0.5)" },
  4: { name: "Zeleni Mag", color: "oklch(0.65 0.18 145)", art: "mag-zeleni", log: "oklch(0.7 0.18 145)", panelBg: "oklch(0.18 0.04 145 / 0.6)", panelBorder: "oklch(0.65 0.18 145 / 0.5)" },
};

/** glow color used under the active player's units on the board */
export const glowColor = (id: PlayerId) => (id === 2 ? "#f2f2f2" : PLAYER_META[id].color);

export const portraitOf = (id: PlayerId) => artOf(PLAYER_META[id].art);

export const wizardCard = (id: PlayerId): DrawnCard => ({
  id: `wizard-${id}`,
  art: PLAYER_META[id].art,
  name: PLAYER_META[id].name,
  kind: "creature",
  size: "W",
  target: 0,
  attack: 3,
  defense: 3,
  move: 1,
  traits: [],
  copies: 1,
  hue: id === 1 ? 90 : id === 2 ? 300 : id === 3 ? 25 : 145,
  uid: `wiz-${id}`,
});

/** effective stats — wizards inherit the stats of the creature they ride */
export const effMove = (u: Unit) =>
  u.isWizard ? (u.mount ? u.mount.move : 1 + (u.boots ? 2 : 0)) : u.card.move;
export const effAttack = (u: Unit) => (u.isWizard && u.mount ? u.mount.attack : u.card.attack);
export const effDefense = (u: Unit) => (u.isWizard && u.mount ? u.mount.defense : u.card.defense);
