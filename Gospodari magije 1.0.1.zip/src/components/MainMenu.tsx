import { useEffect, useRef, useState } from "react";
import { PLAYER_META, portraitOf, type PlayerId } from "@/lib/game-types";

export interface StartConfig {
  mode: "solo" | "hotseat" | "online";
  seats: PlayerId[];
  localId: PlayerId;
  bots: PlayerId[];
  isHost: boolean;
  peer?: any;
  conns?: any[];
  hostConn?: any;
}

const ALL: PlayerId[] = [1, 2, 3, 4];
const roomCode = () => Math.random().toString(36).slice(2, 7).toUpperCase();

/** WebRTC config with public STUN servers — reliable NAT traversal over HTTPS/WSS (also in Electron builds). */
export const PEER_OPTS = {
  secure: true,
  config: {
    iceServers: [
      { urls: "stun:stun.l.google.com:19302" },
      { urls: "stun:stun1.l.google.com:19302" },
      { urls: "stun:stun2.l.google.com:19302" },
    ],
  },
} as const;

export function MainMenu({ onStart }: { onStart: (c: StartConfig) => void }) {
  const [wizard, setWizard] = useState<PlayerId>(1);
  const [mode, setMode] = useState<"solo" | "hotseat" | "online">("solo");
  const [bots, setBots] = useState<1 | 2 | 3>(1);
  const [lobby, setLobby] = useState<null | "host" | "join">(null);

  if (lobby) {
    return (
      <Lobby
        role={lobby}
        wizard={wizard}
        onBack={() => setLobby(null)}
        onStart={onStart}
      />
    );
  }

  const startLocal = () => {
    if (mode === "solo") {
      const others = ALL.filter((id) => id !== wizard).slice(0, bots);
      const seats = [wizard, ...others];
      onStart({ mode: "solo", seats, localId: wizard, bots: others, isHost: true });
    } else {
      const others = ALL.filter((id) => id !== wizard).slice(0, bots);
      onStart({ mode: "hotseat", seats: [wizard, ...others], localId: wizard, bots: [], isHost: true });
    }
  };

  return (
    <main className="grid min-h-screen place-items-center px-6 py-10">
      <div className="panel w-full max-w-3xl p-8">
        <h1 className="text-center font-display text-5xl text-gold-glow">GOSPODARI MAGIJE</h1>

        <div className="mt-8 grid grid-cols-2 gap-5 sm:grid-cols-4">
          {ALL.map((id) => (
            <WizardHex key={id} id={id} selected={wizard === id} onClick={() => setWizard(id)} />
          ))}
        </div>

        <div className="mt-8 grid grid-cols-3 gap-2">
          {([["solo", "Solo vs AI"], ["hotseat", "Lokalno"], ["online", "Online P2P"]] as const).map(([k, label]) => (
            <button
              key={k}
              onClick={() => setMode(k)}
              className={`rounded-md border px-3 py-2 text-xs uppercase tracking-wider transition ${
                mode === k
                  ? "border-[var(--color-gold)] bg-[var(--color-gold)]/15 text-[var(--color-gold)]"
                  : "border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {mode !== "online" ? (
          <div className="mt-5 space-y-3">
            <div className="flex gap-2">
              {([1, 2, 3] as const).map((n) => (
                <button
                  key={n}
                  onClick={() => setBots(n)}
                  className={`flex-1 rounded border px-3 py-2 text-sm ${bots === n ? "border-[var(--color-gold)] text-[var(--color-gold)]" : "border-border text-muted-foreground"}`}
                >
                  {n + 1} maga
                </button>
              ))}
            </div>
            <button className="btn-arcane w-full rounded-md py-3 text-sm" onClick={startLocal}>
              ZAPOČNI BITKU
            </button>
          </div>
        ) : (
          <div className="mt-5 grid grid-cols-2 gap-3">
            <button className="btn-arcane rounded-md py-3 text-sm" onClick={() => setLobby("host")}>KREIRAJ SOBU</button>
            <button className="btn-arcane rounded-md py-3 text-sm" onClick={() => setLobby("join")}>PRIDRUŽI SE SOBI</button>
          </div>
        )}
      </div>
    </main>
  );
}

function WizardHex({ id, selected, onClick, disabled }: { id: PlayerId; selected: boolean; onClick?: () => void; disabled?: boolean }) {
  const meta = PLAYER_META[id];
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`group flex flex-col items-center gap-2 transition ${disabled ? "opacity-30" : "hover:-translate-y-1"}`}
    >
      <span
        className="block h-28 w-24 overflow-hidden"
        style={{
          clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)",
          background: selected ? meta.color : "oklch(0.3 0.02 60)",
          padding: selected ? 3 : 2,
          boxShadow: selected ? `0 0 26px ${meta.color}` : undefined,
        }}
      >
        <img
          src={portraitOf(id)}
          alt={meta.name}
          className="h-full w-full object-cover"
          style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
        />
      </span>
      <span className="font-display text-xs tracking-wider" style={{ color: meta.color }}>{meta.name}</span>
    </button>
  );
}

/* ───────────────────────── P2P lobby ───────────────────────── */

interface LobbySeat { peerId: string; wizard: PlayerId; ready: boolean }

function Lobby({ role, wizard, onBack, onStart }: {
  role: "host" | "join"; wizard: PlayerId; onBack: () => void; onStart: (c: StartConfig) => void;
}) {
  const [code, setCode] = useState(role === "host" ? roomCode() : "");
  const [status, setStatus] = useState(role === "host" ? "Soba se otvara…" : "Unesi kod sobe.");
  const [seats, setSeats] = useState<LobbySeat[]>([]);
  const [myWizard, setMyWizard] = useState<PlayerId>(wizard);
  const [ready, setReady] = useState(false);
  const [connected, setConnected] = useState(false);
  const peerRef = useRef<any>(null);
  const connsRef = useRef<any[]>([]);
  const hostConnRef = useRef<any>(null);
  const seatsRef = useRef<LobbySeat[]>([]);

  const pushSeats = (next: LobbySeat[]) => {
    seatsRef.current = next;
    setSeats(next);
    connsRef.current.forEach((c) => { try { c.send({ type: "lobby", seats: next }); } catch { /* ignore */ } });
  };

  /* host: open room immediately */
  useEffect(() => {
    if (role !== "host") return;
    let cancelled = false;
    (async () => {
      const { default: Peer } = await import("peerjs");
      if (cancelled) return;
      const peer = new Peer(`gospodari-${code}`, PEER_OPTS);
      peerRef.current = peer;
      seatsRef.current = [{ peerId: "host", wizard: myWizard, ready: true }];
      setSeats(seatsRef.current);
      peer.on("open", () => setStatus(`Soba otvorena — podeli kod ${code}`));
      peer.on("error", (e: any) => setStatus(`Greška veze: ${e?.type ?? "nepoznata"}`));
      peer.on("connection", (conn: any) => {
        conn.on("open", () => {
          connsRef.current = [...connsRef.current, conn];
          const taken = new Set(seatsRef.current.map((s) => s.wizard));
          const free = ALL.find((id) => !taken.has(id)) ?? 4;
          pushSeats([...seatsRef.current, { peerId: conn.peer, wizard: free, ready: false }]);
          conn.send({ type: "assign", wizard: free, seats: seatsRef.current });
        });
        conn.on("data", (msg: any) => {
          if (msg?.type === "pick") {
            const taken = new Set(seatsRef.current.filter((s) => s.peerId !== conn.peer).map((s) => s.wizard));
            if (taken.has(msg.wizard)) return;
            pushSeats(seatsRef.current.map((s) => (s.peerId === conn.peer ? { ...s, wizard: msg.wizard } : s)));
          }
          if (msg?.type === "ready") {
            pushSeats(seatsRef.current.map((s) => (s.peerId === conn.peer ? { ...s, ready: !!msg.ready } : s)));
          }
        });
        conn.on("close", () => {
          connsRef.current = connsRef.current.filter((c) => c !== conn);
          pushSeats(seatsRef.current.filter((s) => s.peerId !== conn.peer));
        });
      });
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role]);

  const joinRoom = async () => {
    const { default: Peer } = await import("peerjs");
    setStatus(`Povezivanje na ${code}…`);
    const peer = new Peer(PEER_OPTS);
    peerRef.current = peer;
    peer.on("error", (e: any) => setStatus(`Greška veze: ${e?.type ?? "nepoznata"}`));
    peer.on("open", () => {
      const conn = peer.connect(`gospodari-${code}`, { reliable: true });
      hostConnRef.current = conn;
      conn.on("open", () => { setConnected(true); setStatus("Povezan — izaberi maga i klikni SPREMAN."); });
      conn.on("data", (msg: any) => {
        if (msg?.type === "assign") { setMyWizard(msg.wizard); setSeats(msg.seats ?? []); }
        if (msg?.type === "lobby") setSeats(msg.seats ?? []);
        if (msg?.type === "begin") {
          onStart({
            mode: "online", seats: msg.seats, localId: msg.you, bots: [],
            isHost: false, peer, hostConn: conn,
          });
        }
      });
      conn.on("close", () => setStatus("Veza sa domaćinom je prekinuta."));
    });
  };

  const hostSetWizard = (id: PlayerId) => {
    if (seatsRef.current.some((s) => s.peerId !== "host" && s.wizard === id)) return;
    setMyWizard(id);
    pushSeats(seatsRef.current.map((s) => (s.peerId === "host" ? { ...s, wizard: id } : s)));
  };

  const clientSetWizard = (id: PlayerId) => {
    setMyWizard(id);
    try { hostConnRef.current?.send({ type: "pick", wizard: id }); } catch { /* ignore */ }
  };

  const toggleReady = () => {
    const next = !ready;
    setReady(next);
    try { hostConnRef.current?.send({ type: "ready", ready: next }); } catch { /* ignore */ }
  };

  const startGame = () => {
    const list = seatsRef.current;
    const order = list.map((s) => s.wizard);
    connsRef.current.forEach((c) => {
      const seat = list.find((s) => s.peerId === c.peer);
      try { c.send({ type: "begin", seats: order, you: seat?.wizard }); } catch { /* ignore */ }
    });
    onStart({
      mode: "online", seats: order, localId: myWizard, bots: [],
      isHost: true, peer: peerRef.current, conns: connsRef.current,
    });
  };

  const takenByOthers = new Set(
    seats.filter((s) => (role === "host" ? s.peerId !== "host" : s.wizard !== myWizard)).map((s) => s.wizard),
  );
  const allReady = seats.length >= 2 && seats.every((s) => s.ready);

  return (
    <main className="grid min-h-screen place-items-center px-6 py-10">
      <div className="panel w-full max-w-2xl p-8">
        <h1 className="text-center font-display text-3xl text-gold-glow">
          {role === "host" ? "SOBA DOMAĆINA" : "PRIDRUŽI SE SOBI"}
        </h1>

        <div className="mt-4 flex items-center justify-center gap-2">
          {role === "host" ? (
            <span className="rounded-md border border-[var(--color-gold)]/60 bg-black/40 px-5 py-2 font-display text-2xl tracking-[0.4em] text-[var(--color-gold)]">
              {code}
            </span>
          ) : (
            <>
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6))}
                placeholder="KOD SOBE"
                className="rounded border border-border bg-black/40 px-3 py-2 tracking-[0.3em] text-[var(--color-gold)] outline-none focus:border-[var(--color-gold)]"
              />
              <button className="btn-arcane rounded-md px-4 py-2 text-xs disabled:opacity-40" disabled={!code || connected} onClick={joinRoom}>
                POVEŽI SE
              </button>
            </>
          )}
        </div>

        <p className="mt-3 text-center text-xs text-muted-foreground">{status}</p>

        <div className="mt-6 grid grid-cols-4 gap-3">
          {ALL.map((id) => (
            <WizardHex
              key={id}
              id={id}
              selected={myWizard === id}
              disabled={takenByOthers.has(id) || (role === "join" && !connected)}
              onClick={() => (role === "host" ? hostSetWizard(id) : clientSetWizard(id))}
            />
          ))}
        </div>

        <div className="mt-6 space-y-1">
          {seats.map((s) => (
            <div key={s.peerId} className="flex items-center justify-between rounded border border-border px-3 py-2 text-xs">
              <span style={{ color: PLAYER_META[s.wizard].color }}>
                {PLAYER_META[s.wizard].name}{s.peerId === "host" ? " (domaćin)" : ""}
              </span>
              <span className={s.ready ? "text-[var(--color-gold)]" : "text-muted-foreground"}>
                {s.ready ? "SPREMAN" : "čeka…"}
              </span>
            </div>
          ))}
        </div>

        <div className="mt-6 flex gap-2">
          <button className="rounded-md border border-border px-4 py-2 text-xs text-muted-foreground" onClick={onBack}>Nazad</button>
          {role === "join" && (
            <button className="btn-arcane flex-1 rounded-md py-2 text-xs disabled:opacity-40" disabled={!connected} onClick={toggleReady}>
              {ready ? "OTKAŽI SPREMNOST" : "SPREMAN"}
            </button>
          )}
          {role === "host" && (
            <button className="btn-arcane flex-1 rounded-md py-2 text-xs disabled:opacity-40" disabled={!allReady} onClick={startGame}>
              POKRENI IGRU
            </button>
          )}
        </div>
      </div>
    </main>
  );
}
