import { useEffect, useRef, useState } from "react";
import { artOf } from "@/lib/art";
import {
  allHexes, boardDimensions, eqHex, hexKey, hexPoints, hexToPixel, type OffsetHex,
} from "@/lib/hex";
import { PLAYER_META, effAttack, effDefense, glowColor, type PlayerId, type Unit } from "@/lib/game-types";

const HEX_SIZE = 44;

export function HexBoard({
  units, moveTargets, attackTargets, summonTargets, spellTargets, selectedUid, activeOwner, onHexClick,
}: {
  units: Unit[];
  moveTargets: OffsetHex[];
  attackTargets: OffsetHex[];
  summonTargets: OffsetHex[];
  spellTargets: OffsetHex[];
  selectedUid: string | null;
  /** only this player's units get the under-base aura */
  activeOwner: PlayerId;
  onHexClick: (h: OffsetHex) => void;
}) {
  const dims = boardDimensions(HEX_SIZE);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number; px: number; py: number; moved: boolean } | null>(null);
  const viewportRef = useRef<HTMLDivElement>(null);

  const clampZoom = (z: number) => Math.min(2.6, Math.max(0.5, z));
  const unitAt = (h: OffsetHex) => units.find((u) => eqHex(u.hex, h));
  const sel = units.find((u) => u.uid === selectedUid) ?? null;

  /* native non-passive wheel handler: zoom only the canvas, never scroll the page */
  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setZoom((z) => clampZoom(z - e.deltaY * 0.0015));
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  return (
    <div className="panel relative overflow-hidden p-2" style={{ overscrollBehavior: "contain" }}>
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 40%, oklch(0.26 0.03 55) 0%, oklch(0.1 0.02 40) 75%), repeating-linear-gradient(120deg, rgba(0,0,0,0.28) 0 3px, transparent 3px 9px)",
        }}
      />

      <div
        ref={viewportRef}
        className="relative select-none overflow-hidden"
        style={{
          height: "62vh", minHeight: 400, touchAction: "none", overscrollBehavior: "contain",
          cursor: drag.current ? "grabbing" : "grab",
        }}
        onPointerDown={(e) => {
          drag.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y, moved: false };
          (e.target as Element).setPointerCapture?.(e.pointerId);
        }}
        onPointerMove={(e) => {
          const d = drag.current;
          if (!d) return;
          e.preventDefault();
          const dx = e.clientX - d.x, dy = e.clientY - d.y;
          if (Math.abs(dx) + Math.abs(dy) > 4) d.moved = true;
          setPan({ x: d.px + dx, y: d.py + dy });
        }}
        onPointerUp={() => { drag.current = null; }}
        onPointerLeave={() => { drag.current = null; }}
      >
        <div
          className="h-full w-full origin-center"
          style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transition: drag.current ? "none" : "transform 0.12s ease-out" }}
        >
          <svg viewBox={`0 0 ${dims.w} ${dims.h}`} className="mx-auto block h-full w-full">
            <defs>
              <filter id="base-aura" x="-70%" y="-70%" width="240%" height="240%">
                <feGaussianBlur stdDeviation="6" />
              </filter>
            </defs>
            {allHexes().map((h) => {
              const { x, y } = hexToPixel(h.row, h.col, HEX_SIZE);
              const u = unitAt(h);
              const isAtk = attackTargets.some((m) => eqHex(m, h));
              const isSummon = summonTargets.some((m) => eqHex(m, h));
              const isSpell = spellTargets.some((m) => eqHex(m, h));
              const isMove = moveTargets.some((m) => eqHex(m, h));
              const isSel = sel && eqHex(sel.hex, h);
              const fill = isAtk ? "oklch(0.45 0.2 25 / 0.62)"
                : isSummon ? "oklch(0.55 0.16 145 / 0.5)"
                : isSpell ? "oklch(0.62 0.19 300 / 0.45)"
                : isMove ? "oklch(0.55 0.13 235 / 0.42)"
                : "oklch(0.22 0.02 45 / 0.55)";
              return (
                <g
                  key={hexKey(h)}
                  className="cursor-pointer"
                  onClick={() => { if (!drag.current?.moved) onHexClick(h); }}
                >
                  <polygon
                    points={hexPoints(x, y, HEX_SIZE - 1.5)}
                    fill={fill}
                    stroke={isSel ? "var(--color-gold)" : "oklch(0.75 0.02 80 / 0.35)"}
                    strokeWidth={isSel ? 3 : 1.2}
                  />
                  {u && <UnitToken u={u} x={x} y={y} active={u.owner === activeOwner} />}
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      <div className="absolute bottom-3 left-3 flex gap-1">
        {[["+", () => setZoom((z) => clampZoom(z + 0.2))], ["−", () => setZoom((z) => clampZoom(z - 0.2))],
          ["⟲", () => { setZoom(1); setPan({ x: 0, y: 0 }); }]].map(([label, fn]) => (
          <button
            key={label as string}
            onClick={fn as () => void}
            className="grid h-8 w-8 place-items-center rounded border border-[var(--color-gold)]/50 bg-black/60 text-sm text-[var(--color-gold)]"
          >
            {label as string}
          </button>
        ))}
      </div>
    </div>
  );
}

function UnitToken({ u, x, y, active }: { u: Unit; x: number; y: number; active: boolean }) {
  const color = u.owner === 0 ? "oklch(0.8 0.14 60)" : PLAYER_META[u.owner as PlayerId].color;
  const r = HEX_SIZE - 6;
  const clipId = `clip-${u.uid}`;
  const showStats = u.owner !== 0;
  const aura = active && u.owner !== 0 ? glowColor(u.owner as PlayerId) : null;
  return (
    <g>
      {aura && (
        <ellipse
          cx={x} cy={y + r * 0.78} rx={r * 0.85} ry={r * 0.3}
          fill={aura} opacity={u.isWizard ? 0.95 : 0.5} filter="url(#base-aura)"
        />
      )}
      <defs>
        <clipPath id={clipId}>
          <polygon points={hexPoints(x, y, r)} />
        </clipPath>
      </defs>
      <image
        href={artOf(u.mount ? u.mount.art : u.card.art)}
        x={x - r} y={y - r} width={r * 2} height={r * 2}
        preserveAspectRatio="xMidYMid slice"
        clipPath={`url(#${clipId})`}
      />
      <polygon points={hexPoints(x, y, r)} fill="none" stroke={color} strokeWidth={2.5} />

      {u.isWizard && (
        <g>
          <circle cx={x} cy={y - r * 0.78} r={8} fill="rgba(0,0,0,0.75)" stroke={color} strokeWidth={1.4} />
          <text x={x} y={y - r * 0.78 + 3.4} textAnchor="middle" fontSize="9" fill={color}>★</text>
        </g>
      )}
      {u.mount && (
        <text x={x} y={y + r * 0.05} textAnchor="middle" fontSize="15" fill="var(--color-gold)">🜲</text>
      )}

      {showStats && (
        <g>
          <rect x={x - r + 3} y={y + r * 0.5} width={38} height={13} rx={3} fill="rgba(0,0,0,0.78)" />
          <text x={x - r + 22} y={y + r * 0.5 + 9.6} textAnchor="middle" fontSize="8.5" fill="oklch(0.9 0.06 80)">
            {effAttack(u)}/{effDefense(u)}
          </text>
        </g>
      )}
    </g>
  );
}
